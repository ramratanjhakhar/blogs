
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
  <head>
    <title>412 Precondition Failed</title>
  </head>
  <body>
    <h1>Error 412 Precondition Failed</h1>
    <p>Precondition Failed</p>
    <h3>Error 54113</h3>
    <p>Details: cache-bom4747-BOM 1742982103 2659236716</p>
    <hr>
    <p>Varnish cache server</p>
  </body>
</html>
